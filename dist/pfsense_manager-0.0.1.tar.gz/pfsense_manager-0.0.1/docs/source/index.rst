.. pfsense_manager documentation master file, created by
   sphinx-quickstart on Tue Jan  2 11:53:53 2024.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to pfsense_manager's documentation!
===========================================

.. toctree::
   :maxdepth: 2
   :caption: Contents:

   main.rst
   aliases.rst
   rules.rst
   logs.rst
   dhcp.rst

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
