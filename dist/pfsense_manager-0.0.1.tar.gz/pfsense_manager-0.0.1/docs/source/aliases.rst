Module `pfsense_manager.aliases` 
================================
.. automodule:: pfsense_manager.aliases