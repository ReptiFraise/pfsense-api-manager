Module `pfsense_manager.logs` 
=============================
.. automodule:: pfsense_manager.logs