Module `pfsense_manager.main` 
=============================
.. automodule:: pfsense_manager.main
