Module `pfsense_manager.rules` 
==============================
.. automodule:: pfsense_manager.rules